 
              // <div key={i}>
              //   <img src={item.thumbnail} />
              //   <h2>{item.id}</h2>
              //   <h2>brand:-{item.brand}</h2>
              //   <h2>category:-{item.category}</h2>
              //   <h2>{item.description}</h2>
              //   <h2>{item.title}</h2>
              //   <h2>{item.price}$Only</h2>
              //   <h2>discount:-{item.discountPercentage}%Off</h2>
              //   <h2>stock:-{item.stock}</h2>
              //   <h2>rating:-{item.rating}</h2>
              // </div>